# Validation script for task_2_Restaurant
# Task: Book a winery tour in Napa Valley in a winery which serves Mediterranean cuisine with wine testing for 4 guests on April 15, 10 am in a outdoor setup.
# Domain: Restaurant

import re
from bs4 import BeautifulSoup
from typing import List, Dict, Any, Optional

class Extractor:
    def extract_element_info(self, html: str, action: Dict[str, Any]) -> Dict[str, Any]:
        """Extract information about target elements from HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        element_info = {}
        if 'selector' in action:
            element = soup.select_one(action['selector'])
            element_info['exists'] = element is not None
            element_info['attributes'] = element.attrs if element else {}
        return element_info
    
    def extract_action_sequence(self, actions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Extract and parse action sequence information"""
        return [
            {
                'type': action.get('type'),
                'selector': action.get('selector'),
                'value': action.get('value')
            }
            for action in actions
        ]

class Verifier:
    def verify_element_exists(self, html: str, selector: Optional[str]) -> bool:
        """Verify if target element exists in HTML"""
        if not selector:
            return False
        soup = BeautifulSoup(html, 'html.parser')
        return bool(soup.select_one(selector))
    
    def verify_action_feasibility(self, action: Dict[str, Any], html: str) -> bool:
        """Verify if action can be performed on the webpage"""
        if action['type'] in {'CLICK', 'TYPE', 'SELECT'}:
            return self.verify_element_exists(html, action.get('selector'))
        return False
    
    def verify_sequence_logic(self, actions: List[Dict[str, Any]]) -> bool:
        """Verify logical consistency of action sequence"""
        for i, action in enumerate(actions):
            if action['type'] == 'TYPE' and i > 0:
                if actions[i-1]['type'] != 'CLICK':
                    return False
        return True

class RubricManager:
    def __init__(self):
        self.criteria = {
            'element_validity': 0.3,
            'sequence_logic': 0.3, 
            'task_completion': 0.4
        }
    
    def evaluate(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Main evaluation function"""
        extractor = Extractor()
        verifier = Verifier()
        
        html = task_data.get('html', '')
        actions = task_data.get('actions', [])
        
        if not html or not actions:
            return {
                'element_validity_score': 0,
                'sequence_logic_score': 0,
                'task_completion_score': 0,
                'total_score': 0
            }
        
        parsed_actions = extractor.extract_action_sequence(actions)
        
        element_validity_score = sum(
            verifier.verify_element_exists(html, action.get('selector'))
            for action in parsed_actions
        ) / len(parsed_actions) if parsed_actions else 0
        
        sequence_logic_score = 1 if verifier.verify_sequence_logic(parsed_actions) else 0
        
        task_completion_score = 1 if self.check_task_completion(parsed_actions) else 0
        
        total_score = (
            element_validity_score * self.criteria['element_validity'] +
            sequence_logic_score * self.criteria['sequence_logic'] +
            task_completion_score * self.criteria['task_completion']
        )
        
        return {
            'element_validity_score': element_validity_score,
            'sequence_logic_score': sequence_logic_score,
            'task_completion_score': task_completion_score,
            'total_score': total_score
        }
    
    def check_task_completion(self, actions: List[Dict[str, Any]]) -> bool:
        """Check if the action sequence completes the task"""
        return actions and actions[-1]['type'] == 'SUBMIT'

# Example usage
task_data = {
    'html': '<html><body><div id="reservation"><button id="submit">Submit</button></div></body></html>',
    'actions': [
        {'type': 'CLICK', 'selector': '#reservation button', 'value': None},
        {'type': 'SUBMIT', 'selector': '#submit', 'value': None}
    ]
}

rubric_manager = RubricManager()
evaluation_report = rubric_manager.evaluate(task_data)
print(evaluation_report)