# Validation script for task_1_Restaurant
# Task: Check for pickup restaurant available in Boston, NY on March 18, 5pm with just one guest
# Domain: Restaurant

import re
from bs4 import BeautifulSoup

class Extractor:
    def extract_element_info(self, html: str, action: dict) -> dict:
        """Extract information about target elements from HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        element_info = {}
        action_str = action.get('action', '')
        if 'SELECT' in action_str:
            element_info['type'] = 'combobox'
            element_info['value'] = action_str.split('-> SELECT: ')[1].strip()
        elif 'CLICK' in action_str:
            element_info['type'] = 'clickable'
            element_info['selector'] = action_str.split('-> CLICK')[0].strip()
        elif 'TYPE' in action_str:
            element_info['type'] = 'input'
            element_info['value'] = action_str.split('-> TYPE: ')[1].strip()
        return element_info
    
    def extract_action_sequence(self, actions: list) -> list:
        """Extract and parse action sequence information"""
        parsed_actions = []
        for action in actions:
            match = re.search(r'\[(.*?)\]', action)
            if match:
                action_type = match.group(1)
                parsed_actions.append({'type': action_type, 'action': action})
        return parsed_actions

class Verifier:
    def verify_element_exists(self, html: str, selector: str) -> bool:
        """Verify if target element exists in HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        return bool(soup.select(selector))
    
    def verify_action_feasibility(self, action: dict, html: str) -> bool:
        """Verify if action can be performed on the webpage"""
        element_info = Extractor().extract_element_info(html, action)
        if element_info['type'] == 'combobox':
            return self.verify_element_exists(html, f"select option:contains('{element_info['value']}')")
        elif element_info['type'] == 'clickable':
            return self.verify_element_exists(html, element_info['selector'])
        elif element_info['type'] == 'input':
            return self.verify_element_exists(html, 'input')
        return False
    
    def verify_sequence_logic(self, actions: list) -> bool:
        """Verify logical consistency of action sequence"""
        # Example logic: ensure 'SELECT' action comes before 'CLICK' on a button
        for i, action in enumerate(actions):
            if 'SELECT' in action['action'] and i + 1 < len(actions):
                if 'CLICK' not in actions[i + 1]['action']:
                    return False
        return True

class RubricManager:
    def __init__(self):
        self.criteria = {
            'element_validity': 0.3,
            'sequence_logic': 0.3, 
            'task_completion': 0.4
        }
    
    def evaluate(self, task_data: dict) -> dict:
        """Main evaluation function"""
        html = task_data.get('html', '')
        actions = task_data.get('actions', [])
        
        extractor = Extractor()
        verifier = Verifier()
        
        parsed_actions = extractor.extract_action_sequence(actions)
        
        if not parsed_actions:
            return {
                'element_validity_score': 0,
                'sequence_logic_score': 0,
                'task_completion_score': 0,
                'total_score': 0
            }
        
        element_validity_score = sum(verifier.verify_action_feasibility(action, html) for action in parsed_actions) / len(parsed_actions)
        sequence_logic_score = verifier.verify_sequence_logic(parsed_actions)
        
        # Placeholder for task completion verification
        task_completion_score = 1.0  # Assume task completion for simplicity
        
        total_score = (
            element_validity_score * self.criteria['element_validity'] +
            sequence_logic_score * self.criteria['sequence_logic'] +
            task_completion_score * self.criteria['task_completion']
        )
        
        return {
            'element_validity_score': element_validity_score,
            'sequence_logic_score': sequence_logic_score,
            'task_completion_score': task_completion_score,
            'total_score': total_score
        }

# Example usage
task_data = {
    'html': '<html><body><select><option>Pickup</option></select><div class="clickable"></div><input type="text"></body></html>',
    'actions': [
        '[combobox]  Reservation type -> SELECT: Pickup',
        '[svg]   -> CLICK',
        '[searchbox]  Find a location -> TYPE: Boston',
        '[span]  Boston -> CLICK',
        '[svg]   -> CLICK'
    ]
}

rubric_manager = RubricManager()
evaluation_report = rubric_manager.evaluate(task_data)
print(evaluation_report)