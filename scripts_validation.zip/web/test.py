from openai import OpenAI
from datasets import load_dataset
import random
import json
import os
import traceback
from typing import Dict, List, Any
import time

# 1. 只加载 Mind2Web 数据集的少量样本（避免下载整个大数据集）
print("正在加载 Mind2Web 数据集的少量样本...")
try:
    # 使用 streaming=True 来避免下载整个数据集
    dataset = load_dataset("osunlp/Mind2Web", streaming=True)
    print("数据集加载完毕！")
    
    # 先查看数据集有哪些分割
    print(f"数据集可用分割: {list(dataset.keys())}")
    
    # 尝试获取测试集，如果没有则使用训练集
    if 'test' in dataset:
        data_stream = dataset['test']
        print("使用测试集")
    elif 'train' in dataset:
        data_stream = dataset['train']
        print("使用训练集")
    else:
        # 如果都没有，使用第一个可用的分割
        split_name = list(dataset.keys())[0]
        data_stream = dataset[split_name]
        print(f"使用 {split_name} 分割")
    
    samples = []
    
    print("正在获取前5个样本...")
    for i, sample in enumerate(data_stream):
        if i >= 5:  # 只获取前5个样本
            break
        samples.append(sample)
        print(f"已获取样本 {i+1}/5")

    
except Exception as e:
    print(f"加载数据集时出错: {e}")

OPENAI_API_KEY = "sk-OBJjbt5QYrQh8X6aA3421f234dE34477BaB2Cb583bD116C0"
API_URL = "https://api.sttai.cc/v1"
client = OpenAI(
    api_key=OPENAI_API_KEY,
    base_url=API_URL
)

class Mind2WebValidationGenerator:
    """
    Mind2Web validation script generator inspired by Mind2Web2 methodology
    """
    
    def __init__(self, client: OpenAI):
        self.client = client
        self.selected_tasks = []
        self.generated_scripts = {}
        
    def analyze_tasks(self, samples: List[Dict]) -> List[Dict]:
        """Analyze and select 2-3 representative tasks from Mind2Web dataset"""
        print("Analyzing tasks and selecting representative samples...")
        
        # Group tasks by type/domain for better coverage
        task_groups = {}
        for sample in samples:
            task = sample.get('confirmed_task', 'Unknown')
            domain = sample.get('subdomain', 'Unknown')
            
            key = f"{domain}_{task[:50]}"  # Truncate for grouping
            if key not in task_groups:
                task_groups[key] = []
            task_groups[key].append(sample)
        
        # Select 2-3 diverse tasks
        selected = []
        for group_key, group_samples in list(task_groups.items())[:3]:
            selected.append(group_samples[0])  # Take first sample from each group
            
        self.selected_tasks = selected
        print(f"Selected {len(selected)} representative tasks")
        return selected
    
    def generate_validation_prompt(self, task_sample: Dict) -> str:
        """Generate detailed prompt for LLM to create validation script"""
        
        # Extract key information from the task
        task_description = task_sample.get('confirmed_task', 'N/A')
        domain = task_sample.get('subdomain', 'N/A') 
        actions = task_sample.get('action_reprs', [])
        print(task_description)
        print(actions)
        
        prompt = f"""
You are an expert code generator specializing in creating validation scripts for web interaction datasets. 
I need you to generate a comprehensive validation script for a Mind2Web dataset task.

**TASK CONTEXT:**
- Task Description: {task_description}
- Website Domain: {domain}
- Number of Actions: {len(actions) if actions else 0}
- Sample Actions: {actions[:5] if actions else 'None'}

**BENCHMARK GOALS:**
Our validation framework aims to ensure the quality and correctness of web interaction sequences in the Mind2Web dataset. The validation should cover:
1. Action sequence logical consistency
2. HTML element accessibility and validity
3. Task completion verification
4. Error handling and edge cases

**RUBRIC DESIGN PRINCIPLES:**
1. **Completeness**: Verify all required actions are present and properly sequenced
2. **Accuracy**: Validate that actions target correct HTML elements
3. **Feasibility**: Ensure actions can be realistically executed on the given webpage
4. **Goal Achievement**: Confirm the action sequence leads to task completion

**EVALUATION STRATEGIES:**
- Static analysis of action sequences
- HTML parsing and element validation
- Logical flow verification
- Boundary condition testing

**CORE EVALUATION TOOLKIT:**
Please implement the following key components:

```python
class Extractor:
    def extract_element_info(self, html: str, action: dict) -> dict:
        \"\"\"Extract information about target elements from HTML\"\"\"
        pass
    
    def extract_action_sequence(self, actions: list) -> dict:
        \"\"\"Extract and parse action sequence information\"\"\"
        pass

class Verifier:
    def verify_element_exists(self, html: str, selector: str) -> bool:
        \"\"\"Verify if target element exists in HTML\"\"\"
        pass
    
    def verify_action_feasibility(self, action: dict, html: str) -> bool:
        \"\"\"Verify if action can be performed on the webpage\"\"\"
        pass
    
    def verify_sequence_logic(self, actions: list) -> bool:
        \"\"\"Verify logical consistency of action sequence\"\"\"
        pass

class RubricManager:
    def __init__(self):
        self.criteria = {{
            'element_validity': 0.3,
            'sequence_logic': 0.3, 
            'task_completion': 0.4
        }}
    
    def evaluate(self, task_data: dict) -> dict:
        \"\"\"Main evaluation function\"\"\"
        pass
```

**COMMON MISTAKES TO AVOID:**
1. Don't assume all HTML elements have standard attributes
2. Handle missing or malformed action data gracefully
3. Consider different action types (click, type, select, etc.)
4. Account for dynamic web content that may not be captured in static HTML
5. Validate coordinate-based actions against element positions

**QUALITY GUIDELINES:**
1. Include comprehensive error handling
2. Provide detailed logging and feedback
3. Make the validation process transparent and debuggable
4. Consider edge cases and boundary conditions
5. Ensure the script is modular and maintainable

**SPECIFIC REQUIREMENTS:**
Generate a complete Python validation script that:
1. Takes the Mind2Web task sample as input
2. Implements all core evaluation toolkit classes
3. Performs comprehensive validation following the rubric
4. Returns a detailed evaluation report with scores and explanations
5. Handles errors gracefully and provides meaningful feedback

**IMPORTANT OUTPUT FORMAT REQUIREMENTS:**
- Generate ONLY executable Python code
- Do NOT include any Markdown formatting (no ```)
- Do NOT include any explanatory text outside of Python comments
- Start directly with Python imports or class definitions
- Use proper Python # comments for documentation
- Ensure the script is immediately executable

The script should be production-ready and thoroughly documented. Focus on creating a robust, practical implementation that can handle real-world data variations.

Please generate the complete validation script now as pure Python code:
"""
        return prompt.strip()
    
    def generate_validation_script(self, task_sample: Dict) -> str:
        """Use GPT-4o to generate validation script for a specific task"""
        
        prompt = self.generate_validation_prompt(task_sample)
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system", 
                        "content": "You are an expert Python developer specializing in data validation and web automation. Generate clean, well-documented, and robust code. IMPORTANT: Return ONLY executable Python code without any Markdown formatting, explanatory text, or code block markers. Start directly with imports or class definitions."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=4000,
                temperature=0.3,
                n = 1
            )
            
            raw_script = response.choices[0].message.content
            
            # Clean any potential Markdown formatting
            cleaned_script = self.clean_markdown_script(raw_script)
            
            return cleaned_script
            
        except Exception as e:
            print(f"Error generating validation script: {e}")
            return None
    
    def self_debug_with_system_feedback(self, script_code: str, task_sample: Dict, max_iterations: int = 3) -> str:
        """Implement self-debug with system feedback"""
        
        print("Starting self-debug with system feedback...")
        current_script = script_code
        
        for iteration in range(max_iterations):
            print(f"Debug iteration {iteration + 1}/{max_iterations}")
            
            # Try to execute the script and capture errors
            error_message = self._test_script_execution(current_script, task_sample)
            
            if not error_message:
                print("Script executed successfully!")
                break
                
            print(f"Found error: {error_message}")
            
            # Generate debugging prompt
            debug_prompt = f"""
The following Python validation script has a runtime error. Please fix the error and return the corrected complete script.

**ORIGINAL SCRIPT:**
```python
{current_script}
```

**ERROR MESSAGE:**
{error_message}

**DEBUGGING INSTRUCTIONS:**
1. Analyze the error message carefully
2. Identify the root cause of the issue
3. Fix the error while maintaining the original functionality
4. Ensure all imports are included
5. Make sure the script can handle edge cases

Please provide the complete corrected script:
"""
            
            try:
                response = self.client.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {
                            "role": "system",
                            "content": "You are an expert Python debugger. Fix the error while preserving the original functionality. Return ONLY executable Python code without Markdown formatting."
                        },
                        {
                            "role": "user", 
                            "content": debug_prompt
                        }
                    ],
                    max_tokens=4000,
                    temperature=0.1
                )
                
                raw_script = response.choices[0].message.content
                current_script = self.clean_markdown_script(raw_script)
                print("Script updated based on error feedback")
                
            except Exception as e:
                print(f"Error during debugging iteration {iteration + 1}: {e}")
                break
        
        return current_script
    
    def self_debug_with_reflection(self, script_code: str, task_sample: Dict) -> str:
        """Implement self-debug with self-reflection"""
        
        print("Starting self-debug with reflection...")
        
        reflection_prompt = f"""
Please review and improve the following validation script using this quality checklist:

**SCRIPT TO REVIEW:**
```python
{script_code}
```

**QUALITY CHECKLIST:**
1. **Script Correctness**: Are there any logical errors or bugs?
2. **Logical Coherence**: Does the validation flow make sense?
3. **Rubric Completeness**: Are all evaluation criteria properly implemented?
4. **Edge Cases**: Are edge cases and error conditions handled?
5. **Code Quality**: Is the code well-structured and documented?
6. **Robustness**: Can the script handle various input formats?

**REFLECTION QUESTIONS:**
- Are there any overlooked validation aspects?
- Could the scoring mechanism be improved?
- Are error messages helpful and informative?
- Is the code modular and maintainable?
- Are there any performance concerns?

Please provide an improved version of the script that addresses any identified issues:
"""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": "You are a senior code reviewer with expertise in validation systems. Provide thoughtful improvements to the code. Return ONLY executable Python code without Markdown formatting."
                    },
                    {
                        "role": "user",
                        "content": reflection_prompt
                    }
                ],
                max_tokens=4000,
                temperature=0.2
            )
            
            raw_script = response.choices[0].message.content
            return self.clean_markdown_script(raw_script)
            
        except Exception as e:
            print(f"Error during reflection: {e}")
            return script_code
    
    def _test_script_execution(self, script_code: str, task_sample: Dict) -> str:
        """Test script execution and capture any errors"""
        
        try:
            # Create a safe environment for testing
            test_globals = {
                '__builtins__': __builtins__,
                'task_sample': task_sample
            }
            
            # Execute the script in controlled environment  
            exec(script_code, test_globals)
            
            return None  # No error
            
        except Exception as e:
            return f"{type(e).__name__}: {str(e)}\n{traceback.format_exc()}"
    
    def generate_and_debug_script(self, task_sample: Dict) -> str:
        """Complete pipeline: generate, debug, and refine validation script"""
        
        print(f"\n{'='*60}")
        print(f"Generating validation script for task: {task_sample.get('confirmed_task', 'Unknown')[:50]}...")
        print(f"{'='*60}")
        
        # Step 1: Generate initial script
        print("Step 1: Generating initial validation script...")
        initial_script = self.generate_validation_script(task_sample)
        
        if not initial_script:
            print("Failed to generate initial script")
            return None
        
        # Step 2: Self-debug with system feedback
        print("Step 2: Self-debugging with system feedback...")
        debugged_script = self.self_debug_with_system_feedback(initial_script, task_sample)
        
        # Step 3: Self-debug with reflection
        print("Step 3: Self-debugging with reflection...")
        final_script = self.self_debug_with_reflection(debugged_script, task_sample)
        
        return final_script
    
    def run_validation_pipeline(self, samples: List[Dict]) -> Dict[str, str]:
        """Run the complete validation script generation pipeline"""
        
        print("Starting Mind2Web validation script generation pipeline...")
        print("="*80)
        
        # Analyze and select representative tasks
        selected_tasks = self.analyze_tasks(samples)
        
        generated_scripts = {}
        
        for i, task in enumerate(selected_tasks):
            task_id = f"task_{i+1}_{task.get('subdomain', 'unknown')}"
            
            # Generate and debug validation script
            script = self.generate_and_debug_script(task)
            
            if script:
                generated_scripts[task_id] = {
                    'script': script,
                    'task_info': {
                        'description': task.get('confirmed_task', 'N/A'),
                        'domain': task.get('subdomain', 'N/A'),
                        'actions_count': len(task.get('action_reprs', []))
                    }
                }
                
                # Save script to file
                filename = f"validation_script_{task_id}.py"
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(f"# Validation script for {task_id}\n")
                    f.write(f"# Task: {task.get('confirmed_task', 'N/A')}\n")
                    f.write(f"# Domain: {task.get('subdomain', 'N/A')}\n\n")
                    f.write(script)
                
                print(f"✅ Generated and saved validation script: {filename}")
            else:
                print(f"❌ Failed to generate script for {task_id}")
        
        self.generated_scripts = generated_scripts
        return generated_scripts
    
    def clean_markdown_script(self, script_content: str) -> str:
        """Clean Markdown formatting from generated script"""
        
        print("Cleaning Markdown formatting from script...")
        
        lines = script_content.split('\n')
        cleaned_lines = []
        in_code_block = False
        skip_text = True  # Skip text until we find the first code block
        
        for line in lines:
            # Remove code block markers
            if line.strip().startswith('```'):
                if not in_code_block:
                    # Starting a code block
                    in_code_block = True
                    skip_text = False  # Found code, stop skipping
                else:
                    # Ending a code block
                    in_code_block = False
                    skip_text = True  # Skip text after code blocks
                continue
            
            if in_code_block:
                # Inside code block, keep as is
                cleaned_lines.append(line)
            elif not skip_text:
                # Outside code block but after we've seen code
                # Convert explanatory text to comments
                if line.strip():
                    if line.strip().startswith('#'):
                        # Already a comment
                        cleaned_lines.append(line)
                    elif line.strip().startswith('###') or line.strip().startswith('##'):
                        # Markdown header
                        cleaned_lines.append(f"# {line.strip().lstrip('#').strip()}")
                    else:
                        # Regular text, convert to comment
                        cleaned_lines.append(f"# {line.strip()}")
                else:
                    # Empty line
                    cleaned_lines.append(line)
            # Skip everything else (text before code blocks)
        
        # If no code blocks were found, assume the entire content is code
        if skip_text and not cleaned_lines:
            print("No code blocks found, treating entire content as Python code")
            return script_content.strip()
        
        # Join lines and remove excessive blank lines
        cleaned_script = '\n'.join(cleaned_lines)
        
        # Remove multiple consecutive blank lines
        import re
        cleaned_script = re.sub(r'\n\s*\n\s*\n', '\n\n', cleaned_script)
        
        return cleaned_script.strip()

# Main execution
if __name__ == "__main__":
    print("Mind2Web Validation Script Generator")
    print("Inspired by Mind2Web2 methodology")
    print("="*50)
    
    # Initialize the validation generator
    generator = Mind2WebValidationGenerator(client)
    
    # Run the complete pipeline
    results = generator.run_validation_pipeline(samples)
    
    # Print summary
    print("\n" + "="*80)
    print("GENERATION COMPLETE - SUMMARY")
    print("="*80)
    
    for task_id, data in results.items():
        print(f"\n📋 {task_id.upper()}:")
        print(f"   Task: {data['task_info']['description'][:80]}...")
        print(f"   Domain: {data['task_info']['domain']}")
        print(f"   Actions: {data['task_info']['actions_count']}")
        print(f"   Script Length: {len(data['script'])} characters")
        print(f"   File: validation_script_{task_id}.py")
    
    print(f"\n✅ Successfully generated {len(results)} validation scripts")
    print("📁 All scripts saved to current directory")
    
    # Optional: Display one example script
    if results:
        example_task = list(results.keys())[0]
        print(f"\n" + "="*50)
        print(f"EXAMPLE SCRIPT PREVIEW ({example_task}):")
        print("="*50)
        example_script = results[example_task]['script']
        preview_lines = example_script.split('\n')[:30]  # Show first 30 lines
        for line in preview_lines:
            print(line)
        if len(example_script.split('\n')) > 30:
            print("... (script continues) ...")