# Validation script for task_3_Car rental
# Task: Sign Allan Smith for email offers with the email allan.smith@gmail.com and zip code 10001
# Domain: Car rental

import re
from bs4 import BeautifulSoup

class Extractor:
    def extract_element_info(self, html: str, action: dict) -> dict:
        """Extract information about target elements from HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        element_info = {}
        selector = action.get('selector')
        if selector:
            element = soup.select_one(selector)
            element_info['exists'] = element is not None
            if element:
                element_info['attributes'] = element.attrs
        return element_info
    
    def extract_action_sequence(self, actions: list) -> list:
        """Extract and parse action sequence information"""
        parsed_actions = []
        action_pattern = re.compile(r'\[(.*?)\]\s+(.*?)\s+->\s+(.*?):\s+(.*)')
        for action in actions:
            match = action_pattern.match(action)
            if match:
                action_type, element_desc, command, value = match.groups()
                parsed_actions.append({
                    'action_type': action_type.strip(),
                    'element_desc': element_desc.strip(),
                    'command': command.strip(),
                    'value': value.strip()
                })
        return parsed_actions

class Verifier:
    def verify_element_exists(self, html: str, selector: str) -> bool:
        """Verify if target element exists in HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        if selector:
            return bool(soup.find(attrs={"name": selector}))
        return False
    
    def verify_action_feasibility(self, action: dict, html: str) -> bool:
        """Verify if action can be performed on the webpage"""
        element_info = Extractor().extract_element_info(html, action)
        return element_info.get('exists', False)
    
    def verify_sequence_logic(self, actions: list) -> bool:
        """Verify logical consistency of action sequence"""
        required_fields = {'First Name', 'Last Name', 'Email Address', 'Confirm Email Address'}
        filled_fields = {action['element_desc'] for action in actions if action['command'] == 'TYPE'}
        return required_fields.issubset(filled_fields)

class RubricManager:
    def __init__(self):
        self.criteria = {
            'element_validity': 0.3,
            'sequence_logic': 0.3, 
            'task_completion': 0.4
        }
    
    def evaluate(self, task_data: dict) -> dict:
        """Main evaluation function"""
        html = task_data.get('html', '')
        actions = task_data.get('actions', [])
        
        extractor = Extractor()
        verifier = Verifier()
        
        parsed_actions = extractor.extract_action_sequence(actions)
        
        element_validity_score = all(
            verifier.verify_element_exists(html, action.get('element_desc', '')) for action in parsed_actions
        )
        
        sequence_logic_score = verifier.verify_sequence_logic(parsed_actions)
        
        task_completion_score = sequence_logic_score and element_validity_score
        
        scores = {
            'element_validity': element_validity_score * self.criteria['element_validity'],
            'sequence_logic': sequence_logic_score * self.criteria['sequence_logic'],
            'task_completion': task_completion_score * self.criteria['task_completion']
        }
        
        total_score = sum(scores.values())
        
        return {
            'scores': scores,
            'total_score': total_score,
            'details': {
                'element_validity': 'All elements are valid' if element_validity_score else 'Some elements are missing',
                'sequence_logic': 'Sequence logic is correct' if sequence_logic_score else 'Sequence logic is incorrect',
                'task_completion': 'Task is completed successfully' if task_completion_score else 'Task is not completed'
            }
        }

# Example usage
task_data = {
    'html': '<html><body><input name="First Name" required><input name="Last Name" required><input name="Email Address" required><input name="Confirm Email Address" required></body></html>',
    'actions': [
        '[textbox]  First Name (required) -> TYPE: Allan',
        '[textbox]  Last Name (required) -> TYPE: Smith',
        '[textbox]  Email Address (required) -> TYPE: allan.smith@gmail.com',
        '[textbox]  Confirm Email Address (required) -> TYPE: allan.smith@gmail.com'
    ]
}

rubric_manager = RubricManager()
evaluation_report = rubric_manager.evaluate(task_data)
print(evaluation_report)