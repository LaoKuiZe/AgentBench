from openai import OpenAI
import random
import json
import os
import traceback
from typing import Dict, List, Any
import time
from datasets import load_dataset

# SWE-bench Verified Dataset Loader from HuggingFace
class SWEBenchDataLoader:
    """Load REAL SWE-bench Verified code repair tasks from HuggingFace"""
    
    def __init__(self, dataset_name: str = "princeton-nlp/SWE-bench_Verified"):
        self.dataset_name = dataset_name
        self.dataset = None
        self.load_dataset()
        
    def load_dataset(self):
        """Load the SWE-bench Verified dataset from HuggingFace"""
        try:
            print(f"正在从HuggingFace加载SWE-bench Verified数据集: {self.dataset_name}")
            self.dataset = load_dataset(self.dataset_name, split="test")
            print(f"✅ 成功加载 {len(self.dataset)} 个真实代码修复任务样本")
        except Exception as e:
            print(f"❌ 数据集加载失败: {e}")
            print("使用备用样本数据...")
            self.dataset = None
    
    def get_representative_tasks(self, num_tasks: int = 3) -> List[Dict]:
        """获取代表性的代码修复任务"""
        if not self.dataset:
            return self._get_fallback_samples(num_tasks)
        
        # 从不同仓库中选择代表性样本
        selected_tasks = []
        seen_repos = set()
        
        for sample in self.dataset:
            if len(selected_tasks) >= num_tasks:
                break
            
            repo = sample.get('repo', 'unknown')
            if repo not in seen_repos:
                task_data = {
                    'id': sample.get('instance_id', 'unknown'),
                    'repo': repo,
                    'problem_statement': sample.get('problem_statement', ''),
                    'patch': sample.get('patch', ''),
                    'test_patch': sample.get('test_patch', ''),
                    'base_commit': sample.get('base_commit', ''),
                    'fail_to_pass': sample.get('FAIL_TO_PASS', '[]'),
                    'pass_to_pass': sample.get('PASS_TO_PASS', '[]'),
                    'category': self._categorize_repo(repo),
                    'complexity_level': self._assess_complexity(sample.get('problem_statement', '')),
                    'related_concepts': self._extract_code_concepts(sample.get('problem_statement', '')),
                    'has_real_data': True
                }
                selected_tasks.append(task_data)
                seen_repos.add(repo)
        
        return selected_tasks
    
    def _categorize_repo(self, repo: str) -> str:
        """根据仓库分类任务"""
        repo_categories = {
            'django': 'web_framework',
            'flask': 'web_framework', 
            'scikit-learn': 'machine_learning',
            'matplotlib': 'data_visualization',
            'requests': 'http_library',
            'pandas': 'data_processing',
            'numpy': 'numerical_computing',
            'sympy': 'symbolic_computing'
        }
        
        repo_lower = repo.lower()
        for key, category in repo_categories.items():
            if key in repo_lower:
                return category
        return 'general_software'
    
    def _assess_complexity(self, problem_statement: str) -> str:
        """评估问题复杂度"""
        statement_length = len(problem_statement.split())
        if statement_length < 50:
            return 'simple'
        elif statement_length < 200:
            return 'medium'
        else:
            return 'complex'
    
    def _extract_code_concepts(self, problem_statement: str) -> List[str]:
        """提取代码相关概念"""
        concepts = []
        code_keywords = {
            'bug_fix': ['bug', 'error', 'fix', 'issue', 'problem'],
            'feature': ['feature', 'add', 'implement', 'new'],
            'performance': ['performance', 'optimize', 'speed', 'memory'],
            'refactor': ['refactor', 'clean', 'improve', 'restructure'],
            'testing': ['test', 'testing', 'unit test', 'integration']
        }
        
        statement_lower = problem_statement.lower()
        for concept_type, keywords in code_keywords.items():
            if any(keyword in statement_lower for keyword in keywords):
                concepts.append(concept_type)
        
        return concepts if concepts else ['general_coding']
    
    def _get_fallback_samples(self, num_tasks: int) -> List[Dict]:
        """备用样本数据"""
        return [
            {
                'id': 'fallback_swe_001',
                'repo': 'django/django',
                'problem_statement': 'Fix bug in form validation that causes incorrect error messages',
                'patch': 'def validate_form(self):\n    # Fix implementation\n    pass',
                'test_patch': 'def test_form_validation():\n    # Test implementation\n    pass',
                'category': 'web_framework',
                'complexity_level': 'medium',
                'related_concepts': ['bug_fix', 'testing'],
                'has_real_data': False
            },
            {
                'id': 'fallback_swe_002',
                'repo': 'scikit-learn/scikit-learn', 
                'problem_statement': 'Add new feature for model parameter optimization',
                'patch': 'def optimize_parameters(self):\n    # New feature\n    pass',
                'test_patch': 'def test_optimization():\n    # Test new feature\n    pass',
                'category': 'machine_learning',
                'complexity_level': 'complex',
                'related_concepts': ['feature', 'performance'],
                'has_real_data': False
            },
            {
                'id': 'fallback_swe_003',
                'repo': 'matplotlib/matplotlib',
                'problem_statement': 'Refactor plotting code to improve maintainability',
                'patch': 'def create_plot(self):\n    # Refactored code\n    pass',
                'test_patch': 'def test_plotting():\n    # Test refactored code\n    pass', 
                'category': 'data_visualization',
                'complexity_level': 'medium',
                'related_concepts': ['refactor'],
                'has_real_data': False
            }
        ][:num_tasks]

# 初始化SWE-bench数据加载器
swebench_loader = SWEBenchDataLoader()

# API配置 (与test.py相同的密钥)
OPENAI_API_KEY = "sk-OBJjbt5QYrQh8X6aA3421f234dE34477BaB2Cb583bD116C0"
API_URL = "https://api.sttai.cc/v1"
client = OpenAI(
    api_key=OPENAI_API_KEY,
    base_url=API_URL
)

class CodeRepairScoringSystem:
    """针对代码修复任务的增强评分系统"""
    
    def __init__(self):
        self.criteria_weights = {
            'code_fix_correctness': 0.35,     # 代码修复正确性
            'test_pass_rate': 0.25,           # 测试通过率
            'code_quality': 0.20,             # 代码质量
            'issue_resolution_completeness': 0.15,  # 问题解决完整性
            'code_style_consistency': 0.05    # 代码风格一致性
        }
        self.max_score = 100
        
    def calculate_weighted_score(self, criteria_scores: Dict[str, float]) -> float:
        """计算加权综合得分"""
        weighted_sum = 0
        for criterion, score in criteria_scores.items():
            weight = self.criteria_weights.get(criterion, 0)
            weighted_sum += score * weight
        
        final_score = min(weighted_sum * self.max_score, self.max_score)
        return round(final_score, 2)
    
    def generate_comprehensive_report(self, scores: Dict, task_info: Dict) -> str:
        """生成详细的代码修复任务评分报告"""
        report = f"""
=== SWE-bench代码修复任务验证详细报告 ===
任务ID: {task_info.get('id', 'N/A')}
仓库: {task_info.get('repo', 'N/A')}
类别: {task_info.get('category', 'N/A')}
复杂度: {task_info.get('complexity_level', 'N/A')}
相关概念: {task_info.get('related_concepts', [])}

=== 代码修复评分明细 ===
"""
        
        total_score = 0
        for criterion, score in scores.items():
            if criterion in self.criteria_weights:
                weight = self.criteria_weights[criterion]
                weighted_score = score * weight * 100
                total_score += weighted_score
                
                report += f"""
{criterion}:
  原始得分: {score:.3f}/1.0
  权重: {weight:.1%}
  加权得分: {weighted_score:.2f}/100
"""
        
        report += f"""
=== 综合评估 ===
总分: {total_score:.2f}/100

评级: {self._get_code_repair_grade(total_score)}
"""
        return report
    
    def _get_code_repair_grade(self, score: float) -> str:
        """根据分数获取代码修复任务评级"""
        if score >= 90:
            return "优秀修复 (Excellent Code Repair)"
        elif score >= 80:
            return "良好修复 (Good Code Repair)"
        elif score >= 70:
            return "合格修复 (Satisfactory Code Repair)"
        elif score >= 60:
            return "需改进修复 (Code Repair Needs Improvement)"
        else:
            return "不合格修复 (Poor Code Repair)"

class SWEBenchValidationGenerator:
    """
    SWE-bench验证脚本生成器，基于Mind2Web2方法论
    专门适配代码修复和软件工程任务，使用真实SWE-bench Verified数据集
    """
    
    def __init__(self, client: OpenAI, swebench_loader: SWEBenchDataLoader):
        self.client = client
        self.swebench_loader = swebench_loader
        self.scoring_system = CodeRepairScoringSystem()
        self.selected_tasks = []
        self.generated_scripts = {}
        
    def analyze_tasks(self, num_tasks: int = 3) -> List[Dict]:
        """分析并选择来自REAL SWE-bench数据集的代表性代码修复任务"""
        print("正在从HuggingFace SWE-bench Verified数据集分析REAL代码修复任务...")
        
        # 从真实的SWE-bench数据集加载任务
        selected = self.swebench_loader.get_representative_tasks(num_tasks)
        
        self.selected_tasks = selected
        print(f"已选择 {len(selected)} 个来自REAL SWE-bench数据集的代表性代码修复任务")
        
        # 打印任务详情进行验证
        for i, task in enumerate(selected, 1):
            print(f"\n📋 Real Code Repair Task {i}:")
            print(f"   ID: {task['id']}")
            print(f"   Repo: {task['repo']}")
            print(f"   Category: {task['category']}")
            print(f"   Complexity: {task['complexity_level']}")
            print(f"   Related Concepts: {task['related_concepts']}")
            print(f"   Problem: {task['problem_statement'][:100]}...")
            print(f"   Has Real Data: {task.get('has_real_data', False)}")
        
        return selected
    
    def generate_enhanced_code_repair_prompt(self, task_sample: Dict) -> str:
        """为LLM生成增强版prompt，基于REAL SWE-bench数据创建代码修复验证脚本"""
        
        # 提取真实SWE-bench任务的关键信息
        task_id = task_sample.get('id', 'N/A')
        repo = task_sample.get('repo', 'N/A')
        problem_statement = task_sample.get('problem_statement', 'N/A')
        patch = task_sample.get('patch', 'N/A')
        test_patch = task_sample.get('test_patch', 'N/A')
        category = task_sample.get('category', 'N/A')
        complexity_level = task_sample.get('complexity_level', 'N/A')
        related_concepts = task_sample.get('related_concepts', [])
        
        prompt = f"""
You are an expert code generator specializing in creating validation scripts for software engineering and code repair tasks.
I need you to generate a comprehensive validation script for a REAL SWE-bench Verified dataset task.

**REAL SWE-BENCH TASK CONTEXT:**
- Task ID: {task_id}
- Repository: {repo}
- Category: {category}
- Complexity Level: {complexity_level}
- Related Concepts: {related_concepts}
- Problem Statement: {problem_statement[:500]}...
- Patch Preview: {patch[:200]}...
- Test Patch Available: {bool(test_patch)}

**ENHANCED SCORING SYSTEM FOR CODE REPAIR:**
Implement this comprehensive scoring framework with enhanced validation logic.

**❗ CRITICAL EXECUTION REQUIREMENTS - MUST FOLLOW:**
1. **MANDATORY**: Include a complete main() function at the end
2. **MANDATORY**: Include if __name__ == "__main__": main() execution block  
3. **MANDATORY**: The script must print validation results when run
4. **MANDATORY**: Use the real task data provided in the context

**❗ SCRIPT MUST END WITH THIS EXACT PATTERN:**
```python
def main():
    # Real SWE-bench Task Data
    task_data = {{
        'id': '{task_id}',
        'repo': '{repo}', 
        'category': '{category}',
        'complexity_level': '{complexity_level}',
        'related_concepts': {related_concepts},
        'problem_statement': '''{problem_statement[:300]}...''',
        'patch': '''{patch[:200]}...''',
        'test_patch': '''{test_patch[:100] if test_patch else ''}'''
    }}
    
    print("SWE-bench Code Repair Validation Results")
    print("="*60)
    print(f"Task ID: {{task_data['id']}}")
    print(f"Repository: {{task_data['repo']}}")
    print(f"Category: {{task_data['category']}}")
    print(f"Complexity: {{task_data['complexity_level']}}")
    print(f"Related Concepts: {{', '.join(task_data['related_concepts'])}}")
    
    # Execute validation
    validator = CodeRepairValidator()
    validation_results = validator.run_comprehensive_validation(task_data)
    
    print("\\nValidation Results:")
    for key, value in validation_results['validation_results'].items():
        print(f"  {{key}}: {{value}}")
    
    print("\\nDetailed Scores:")
    for criterion, score in validation_results['scores']['criteria_scores'].items():
        print(f"  {{criterion}}: {{score:.2f}}")
    
    print(f"\\nTotal Score: {{validation_results['scores']['weighted_score']:.2f}}/100")
    print(f"Grade: {{validation_results['scores']['grade']}}")
    
    if 'detailed_report' in validation_results:
        print("\\n=== Detailed Code Repair Report ===")
        print(validation_results['detailed_report'])

if __name__ == "__main__":
    main()
```

**VALIDATION CHECK**: Your output must contain both:
- "def main():"
- "if __name__ == \"__main__\":"

Please generate the complete comprehensive SWE-bench validation script that includes:
1. Complete CodeRepairScoringSystem class implementation
2. Complete CodeRepairValidator class with all validation methods
3. Comprehensive scoring logic for the 5 criteria
4. Complete main() function with real task data
5. Proper execution block

Generate ONLY executable Python code (no markdown formatting):
"""
        return prompt.strip()
    
    def generate_and_debug_script(self, task: Dict) -> str:
        """生成并调试SWE-bench验证脚本，使用增强的代码修复评分系统"""
        print(f"\n{'='*60}")
        print(f"为任务生成SWE-bench验证脚本: {task.get('repo', 'N/A')} - {task.get('problem_statement', 'N/A')[:50]}...")
        print("="*60)
        
        # 步骤1: 生成初始脚本
        print("步骤1: 生成初始SWE-bench验证脚本...")
        try:
            prompt = self.generate_enhanced_code_repair_prompt(task)
            print(f"发送prompt到GPT-4o (长度: {len(prompt)} 字符)...")
            
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You are an expert Python code generator specializing in software engineering validation scripts. Generate only executable Python code without any markdown formatting."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=4000,
                temperature=0.1
            )
            
            script_content = response.choices[0].message.content.strip()
            script_content = self._clean_markdown_formatting(script_content)
            print("✅ 成功生成验证脚本")
            
        except Exception as e:
            print(f"❌ 脚本生成错误: {e}")
            return None
        
        # 步骤2: 系统反馈自调试
        print("步骤2: 通过系统反馈进行自调试...")
        debugged_script = self._debug_with_system_feedback(script_content, task, max_iterations=3)
        
        # 步骤3: 自我反思调试
        print("步骤3: 通过自我反思进行调试...")
        final_script = self._debug_with_self_reflection(debugged_script, task)
        
        return final_script
    
    def _clean_markdown_formatting(self, content: str) -> str:
        """清理markdown格式，提取纯Python代码"""
        print("清理Markdown格式...")
        
        # 移除markdown代码块标记
        if "```python" in content:
            content = content.split("```python")[1]
            if "```" in content:
                content = content.split("```")[0]
            print("发现并清理了Python代码块")
        elif "```" in content:
            # 通用代码块处理
            parts = content.split("```")
            if len(parts) >= 3:
                content = parts[1]
                print("发现并清理了通用代码块")
        else:
            print("未发现代码块，将整个内容视为Python代码")
        
        return content.strip()
    
    def _debug_with_system_feedback(self, script: str, task: Dict, max_iterations: int = 3) -> str:
        """通过系统反馈进行自调试"""
        current_script = script
        
        for iteration in range(1, max_iterations + 1):
            print(f"系统反馈调试迭代 {iteration}/{max_iterations}")
            
            # 测试脚本执行
            execution_result = self._test_script_execution(current_script)
            
            if execution_result['success']:
                print("✅ 脚本执行成功")
                break
            else:
                print(f"❌ 脚本执行错误: {execution_result['error']}")
                print(execution_result.get('traceback', ''))
                
                # 生成调试prompt
                debug_prompt = self._generate_debug_prompt(current_script, execution_result, task)
                
                try:
                    response = self.client.chat.completions.create(
                        model="gpt-4o",
                        messages=[
                            {"role": "system", "content": "You are a Python debugging expert. Fix the provided code and return only the corrected Python code without markdown formatting."},
                            {"role": "user", "content": debug_prompt}
                        ],
                        max_tokens=4000,
                        temperature=0.1
                    )
                    
                    current_script = response.choices[0].message.content.strip()
                    current_script = self._clean_markdown_formatting(current_script)
                    print(f"生成调试迭代 {iteration}")
                    
                except Exception as e:
                    print(f"❌ 调试迭代 {iteration} 失败: {e}")
                    break
        
        return current_script
    
    def _test_script_execution(self, script: str) -> Dict:
        """测试脚本执行"""
        try:
            # 创建隔离的执行环境
            test_globals = {
                '__builtins__': __builtins__,
                'print': print,
                'os': __import__('os'),
                'json': __import__('json'),
                'traceback': __import__('traceback'),
                'typing': __import__('typing'),
                're': __import__('re'),
                'ast': __import__('ast')
            }
            
            # 尝试执行脚本
            exec(script, test_globals)
            return {'success': True}
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'traceback': traceback.format_exc()
            }
    
    def _generate_debug_prompt(self, script: str, error_info: Dict, task: Dict) -> str:
        """生成调试prompt"""
        return f"""
The following SWE-bench validation script has an execution error. Please fix it and return only the corrected Python code.

**ORIGINAL SCRIPT:**
{script}

**ERROR INFORMATION:**
Error: {error_info.get('error', 'Unknown')}
Traceback:
{error_info.get('traceback', 'No traceback')}

**TASK CONTEXT:**
Task: {task.get('repo', 'N/A')} - {task.get('problem_statement', 'N/A')[:100]}...
Task Type: {task.get('category', 'N/A')}

**REQUIREMENTS:**
1. Fix the execution error
2. Maintain the enhanced scoring system for code repair
3. Ensure all imports are available or handled gracefully
4. Return only executable Python code (no markdown formatting)
5. Keep the comprehensive validation framework
6. Must include main() function and execution block

Please provide the corrected script:
"""
    
    def _debug_with_self_reflection(self, script: str, task: Dict) -> str:
        """通过自我反思进行调试"""
        print("生成自我反思调试...")
        
        reflection_prompt = f"""
Please review and improve the following SWE-bench validation script through self-reflection.

**CURRENT SCRIPT:**
{script}

**TASK CONTEXT:**
Task: {task.get('repo', 'N/A')} - {task.get('problem_statement', 'N/A')[:100]}...
Has Real Data: {task.get('has_real_data', False)}

**QUALITY CHECKLIST:**
1. ✓ Does the script use the code repair scoring system correctly?
2. ✓ Does it properly validate code fixes from real SWE-bench data?
3. ✓ Are all error cases handled gracefully?
4. ✓ Is the scoring comprehensive with proper weights for code repair?
5. ✓ Does it generate detailed reports for software engineering tasks?
6. ✓ Does it include complete main() function execution?

**IMPROVEMENT AREAS:**
- Code repair validation accuracy
- Test coverage assessment
- Code quality metrics
- Issue resolution completeness

Please provide an improved version of the script with better quality and robustness:
"""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You are a code quality expert for software engineering validation. Improve the provided code and return only the enhanced Python code without markdown formatting."},
                    {"role": "user", "content": reflection_prompt}
                ],
                max_tokens=4000,
                temperature=0.1
            )
            
            improved_script = response.choices[0].message.content.strip()
            improved_script = self._clean_markdown_formatting(improved_script)
            print("✅ 完成自我反思改进")
            return improved_script
            
        except Exception as e:
            print(f"❌ 自我反思过程中出错: {e}")
            return script
    
    def run_validation_pipeline(self) -> Dict[str, str]:
        """运行完整的SWE-bench验证脚本生成流程"""
        
        print("开始SWE-bench验证脚本生成流程...")
        print("="*80)
        
        # 分析并选择代表性任务
        selected_tasks = self.analyze_tasks()
        
        generated_scripts = {}
        
        for i, task in enumerate(selected_tasks):
            task_id = f"task_{i+1}_{task.get('category', 'unknown')}"
            
            # 生成并调试验证脚本
            script = self.generate_and_debug_script(task)
            
            if script:
                generated_scripts[task_id] = {
                    'script': script,
                    'task_info': {
                        'id': task.get('id', 'N/A'),
                        'repo': task.get('repo', 'N/A'),
                        'category': task.get('category', 'N/A'),
                        'complexity_level': task.get('complexity_level', 'N/A'),
                        'related_concepts': task.get('related_concepts', []),
                        'problem_statement': task.get('problem_statement', 'N/A'),
                        'has_real_data': task.get('has_real_data', False)
                    }
                }
                
                # 保存脚本到文件
                filename = f"swebench_validation_script_{task_id}.py"
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(script)
                print(f"✅ 生成并保存SWE-bench验证脚本: {filename}")
        
        return generated_scripts

def main():
    """主函数 - 运行SWE-bench验证脚本生成器"""
    print("\n" + "="*70)
    print("SWE-bench Verified 验证脚本生成器")
    print("基于Mind2Web2方法论，使用HuggingFace真实代码修复任务数据")
    print("="*70)
    
    # 创建生成器实例
    generator = SWEBenchValidationGenerator(client, swebench_loader)
    
    # 运行完整流程，使用REAL SWE-bench任务
    results = generator.run_validation_pipeline()
    
    # 打印总结
    print("\n" + "="*80)
    print("SWE-BENCH 生成完成 - 总结")
    print("="*80)
    
    for task_id, data in results.items():
        print(f"\n📋 {task_id.upper()}:")
        print(f"   Real Task ID: {data['task_info']['id']}")
        print(f"   Repository: {data['task_info']['repo']}")
        print(f"   Category: {data['task_info']['category']}")
        print(f"   Complexity: {data['task_info']['complexity_level']}")
        print(f"   Related Concepts: {', '.join(data['task_info']['related_concepts'])}")
        print(f"   Problem: {data['task_info']['problem_statement'][:80]}...")
        print(f"   Has Real Data: {data['task_info']['has_real_data']}")
        print(f"   Script Length: {len(data['script'])} characters")
        print(f"   File: swebench_validation_script_{task_id}.py")
    
    print(f"\n✅ Successfully generated {len(results)} REAL SWE-bench validation scripts")
    print("📁 All scripts saved to current directory")
    print("🎯 Using authentic SWE-bench Verified dataset with real code repair tasks from HuggingFace")
    print("📊 Enhanced scoring system with comprehensive code repair evaluation metrics")
    
    # 显示一个示例脚本预览
    if results:
        example_task = list(results.keys())[0]
        print(f"\n" + "="*50)
        print(f"ENHANCED SWE-BENCH SCRIPT PREVIEW ({example_task}):")
        print("="*50)
        example_script = results[example_task]['script']
        preview_lines = example_script.split('\n')[:25]  # 显示前25行
        for line in preview_lines:
            print(line)
        if len(example_script.split('\n')) > 25:
            print("... (enhanced script continues with comprehensive code repair validation) ...")

if __name__ == "__main__":
    main() 