from openai import OpenAI
import random
import json
import os
import traceback
from typing import Dict, List, Any
import time
from datasets import load_dataset

# PlanBench Dataset Loader from HuggingFace
class PlanBenchDataLoader:
    """Load REAL PlanBench planning tasks from HuggingFace"""
    
    def __init__(self, dataset_name: str = "tasksource/planbench"):
        self.dataset_name = dataset_name
        self.dataset = None
        self.load_dataset()
        
    def load_dataset(self):
        """Load the PlanBench dataset from HuggingFace with multiple configs"""
        try:
            print(f"正在从HuggingFace加载PlanBench数据集: {self.dataset_name}")
            
            # 加载不同的配置子集
            configs_to_load = [
                'task_1_plan_generation',
                'task_2_plan_optimality', 
                'task_3_plan_verification'
            ]
            
            all_samples = []
            for config in configs_to_load:
                try:
                    print(f"  加载配置: {config}")
                    dataset_config = load_dataset(self.dataset_name, config, split="train")
                    # 为每个样本添加任务类型标识
                    for sample in dataset_config:
                        sample['task'] = config
                        all_samples.append(sample)
                    print(f"  ✅ {config}: {len(dataset_config)} 个样本")
                except Exception as config_error:
                    print(f"  ❌ 配置 {config} 加载失败: {config_error}")
            
            self.dataset = all_samples
            print(f"✅ 总共成功加载 {len(all_samples)} 个真实规划任务样本")
            
        except Exception as e:
            print(f"❌ 数据集加载失败: {e}")
            print("使用备用样本数据...")
            self.dataset = None
    
    def get_representative_tasks(self, num_tasks: int = 3) -> List[Dict]:
        """获取代表性的规划任务"""
        if not self.dataset:
            return self._get_fallback_samples(num_tasks)
        
        # 从不同任务类型中选择代表性样本
        task_types = ["task_1_plan_generation", "task_2_plan_optimality", "task_3_plan_verification"]
        selected_tasks = []
        
        for task_type in task_types:
            if len(selected_tasks) >= num_tasks:
                break
            
            # 寻找该类型的任务
            for sample in self.dataset:
                if sample.get('task') == task_type and len(selected_tasks) < num_tasks:
                    task_data = {
                        'id': f"{task_type}_{sample.get('instance_id', 0)}",
                        'task_type': task_type,
                        'domain': sample.get('domain', 'unknown'),
                        'query': sample.get('query', ''),
                        'ground_truth_plan': sample.get('ground_truth_plan', ''),
                        'instance_id': sample.get('instance_id', 0),
                        'example_instance_ids': sample.get('example_instance_ids', []),
                        'category': self._categorize_domain(sample.get('domain', '')),
                        'complexity_level': self._assess_complexity(sample.get('query', '')),
                        'related_concepts': self._extract_planning_concepts(sample.get('query', '')),
                        'has_real_data': True
                    }
                    selected_tasks.append(task_data)
                    break
        
        return selected_tasks
    
    def _categorize_domain(self, domain: str) -> str:
        """根据领域分类任务"""
        domain_categories = {
            'logistics': 'transportation_planning',
            'blocks': 'spatial_reasoning',
            'gripper': 'robot_manipulation',
            'obfuscated': 'abstract_reasoning'
        }
        
        for key, category in domain_categories.items():
            if key in domain.lower():
                return category
        return 'general_planning'
    
    def _assess_complexity(self, query: str) -> str:
        """评估任务复杂度"""
        query_length = len(query.split())
        if query_length < 200:
            return 'simple'
        elif query_length < 500:
            return 'medium'
        else:
            return 'complex'
    
    def _extract_planning_concepts(self, query: str) -> List[str]:
        """提取规划概念"""
        concepts = []
        planning_keywords = {
            'actions': ['move', 'pick', 'place', 'transport', 'load'],
            'objects': ['object', 'block', 'package', 'truck', 'location'],
            'conditions': ['initial', 'goal', 'precondition', 'effect'],
            'planning': ['plan', 'sequence', 'steps', 'order']
        }
        
        query_lower = query.lower()
        for concept_type, keywords in planning_keywords.items():
            if any(keyword in query_lower for keyword in keywords):
                concepts.append(concept_type)
        
        return concepts if concepts else ['general_planning']
    
    def _get_fallback_samples(self, num_tasks: int) -> List[Dict]:
        """备用样本数据"""
        return [
            {
                'id': 'fallback_plan_gen_001',
                'task_type': 'task_1_plan_generation',
                'domain': 'logistics',
                'query': 'Generate a plan to transport packages from source to destination using trucks',
                'ground_truth_plan': '(load package1 truck1) (drive truck1 location1 location2) (unload package1 truck1)',
                'category': 'transportation_planning',
                'complexity_level': 'simple',
                'related_concepts': ['actions', 'objects', 'planning'],
                'has_real_data': False
            },
            {
                'id': 'fallback_plan_opt_002',
                'task_type': 'task_2_plan_optimality',
                'domain': 'blocks',
                'query': 'Evaluate if the given plan is optimal for stacking blocks',
                'ground_truth_plan': '(pick block1) (stack block1 block2) (pick block3) (stack block3 block1)',
                'category': 'spatial_reasoning',
                'complexity_level': 'medium',
                'related_concepts': ['actions', 'objects', 'conditions'],
                'has_real_data': False
            },
            {
                'id': 'fallback_plan_ver_003', 
                'task_type': 'task_3_plan_verification',
                'domain': 'gripper',
                'query': 'Verify if the plan correctly achieves the goal state',
                'ground_truth_plan': '(pick gripper1 ball1) (move gripper1 room1 room2) (drop gripper1 ball1)',
                'category': 'robot_manipulation',
                'complexity_level': 'medium',
                'related_concepts': ['actions', 'conditions', 'planning'],
                'has_real_data': False
            }
        ][:num_tasks]

# 初始化PlanBench数据加载器
planbench_loader = PlanBenchDataLoader()

# API配置 (与test.py相同的密钥)
OPENAI_API_KEY = "sk-OBJjbt5QYrQh8X6aA3421f234dE34477BaB2Cb583bD116C0"
API_URL = "https://api.sttai.cc/v1"
client = OpenAI(
    api_key=OPENAI_API_KEY,
    base_url=API_URL
)

class PlanningTaskScoringSystem:
    """针对规划任务的增强评分系统"""
    
    def __init__(self):
        self.criteria_weights = {
            'plan_correctness': 0.35,        # 计划正确性
            'plan_optimality': 0.25,         # 计划优化程度
            'logical_consistency': 0.20,     # 逻辑一致性
            'goal_achievement': 0.15,        # 目标达成度
            'error_handling': 0.05           # 错误处理
        }
        self.max_score = 100
        
        # 详细评分子标准
        self.sub_criteria = {
            'plan_correctness': {
                'action_validity': 0.4,         # 动作有效性
                'precondition_satisfaction': 0.3, # 前置条件满足
                'effect_achievement': 0.3        # 效果达成
            },
            'plan_optimality': {
                'step_efficiency': 0.5,         # 步骤效率
                'resource_usage': 0.3,          # 资源使用
                'path_optimality': 0.2          # 路径优化
            },
            'logical_consistency': {
                'state_transitions': 0.5,       # 状态转换
                'constraint_satisfaction': 0.3, # 约束满足
                'sequence_validity': 0.2        # 序列有效性
            },
            'goal_achievement': {
                'final_state_match': 0.6,       # 最终状态匹配
                'intermediate_goals': 0.4       # 中间目标
            },
            'error_handling': {
                'error_detection': 0.6,         # 错误检测
                'recovery_capability': 0.4      # 恢复能力
            }
        }
    
    def calculate_weighted_score(self, criteria_scores: Dict[str, float]) -> float:
        """计算加权综合得分"""
        weighted_sum = 0
        for criterion, score in criteria_scores.items():
            weight = self.criteria_weights.get(criterion, 0)
            weighted_sum += score * weight
        
        final_score = min(weighted_sum * self.max_score, self.max_score)
        return round(final_score, 2)
    
    def generate_comprehensive_report(self, scores: Dict, task_info: Dict) -> str:
        """生成详细的规划任务评分报告"""
        report = f"""
=== PlanBench规划任务验证详细报告 ===
任务ID: {task_info.get('id', 'N/A')}
任务类型: {task_info.get('task_type', 'N/A')}
领域: {task_info.get('domain', 'N/A')}
复杂度: {task_info.get('complexity_level', 'N/A')}
相关概念: {task_info.get('related_concepts', [])}

=== 规划评分明细 ===
"""
        
        total_score = 0
        for criterion, score in scores.items():
            if criterion in self.criteria_weights:
                weight = self.criteria_weights[criterion]
                weighted_score = score * weight * 100
                total_score += weighted_score
                
                report += f"""
{criterion}:
  原始得分: {score:.3f}/1.0
  权重: {weight:.1%}
  加权得分: {weighted_score:.2f}/100
"""
        
        report += f"""
=== 综合评估 ===
总分: {total_score:.2f}/100

评级: {self._get_planning_grade(total_score)}
"""
        return report
    
    def _get_planning_grade(self, score: float) -> str:
        """根据分数获取规划任务评级"""
        if score >= 90:
            return "优秀规划 (Excellent Planning)"
        elif score >= 80:
            return "良好规划 (Good Planning)"
        elif score >= 70:
            return "合格规划 (Satisfactory Planning)"
        elif score >= 60:
            return "需改进规划 (Planning Needs Improvement)"
        else:
            return "不合格规划 (Poor Planning)"

class PlanBenchValidationGenerator:
    """
    PlanBench验证脚本生成器，基于Mind2Web2方法论
    专门适配规划和推理任务，使用真实PlanBench数据集
    """
    
    def __init__(self, client: OpenAI, planbench_loader: PlanBenchDataLoader):
        self.client = client
        self.planbench_loader = planbench_loader
        self.scoring_system = PlanningTaskScoringSystem()
        self.selected_tasks = []
        self.generated_scripts = {}
        
    def analyze_tasks(self, num_tasks: int = 3) -> List[Dict]:
        """分析并选择来自REAL PlanBench数据集的代表性规划任务"""
        print("正在从HuggingFace PlanBench数据集分析REAL规划任务...")
        
        # 从真实的PlanBench数据集加载任务
        selected = self.planbench_loader.get_representative_tasks(num_tasks)
        
        self.selected_tasks = selected
        print(f"已选择 {len(selected)} 个来自REAL PlanBench数据集的代表性规划任务")
        
        # 打印任务详情进行验证
        for i, task in enumerate(selected, 1):
            print(f"\n📋 Real Planning Task {i}:")
            print(f"   ID: {task['id']}")
            print(f"   Task Type: {task['task_type']}")
            print(f"   Domain: {task['domain']}")
            print(f"   Category: {task['category']}")
            print(f"   Complexity: {task['complexity_level']}")
            print(f"   Related Concepts: {task['related_concepts']}")
            print(f"   Query: {task['query'][:100]}...")
            print(f"   Has Real Data: {task.get('has_real_data', False)}")
        
        return selected
    
    def generate_enhanced_planning_prompt(self, task_sample: Dict) -> str:
        """为LLM生成精简版prompt，突出main函数要求"""
        
        # 提取真实PlanBench任务的关键信息
        task_id = task_sample.get('id', 'N/A')
        task_type = task_sample.get('task_type', 'N/A')
        domain = task_sample.get('domain', 'N/A')
        query = task_sample.get('query', 'N/A')
        ground_truth_plan = task_sample.get('ground_truth_plan', 'N/A')
        related_concepts = task_sample.get('related_concepts', [])
        
        prompt = f"""
Generate a Python validation script for this REAL PlanBench planning task:

**TASK INFO:**
- ID: {task_id}
- Type: {task_type} 
- Domain: {domain}
- Query: {query[:300]}...
- Ground Truth Plan: {ground_truth_plan[:200]}...

**🚨 CRITICAL: MUST INCLUDE THESE EXACT COMPONENTS:**

1. **PlanningTaskScoringSystem class** with 5 criteria weights
2. **PlanValidator class** with validation methods
3. **MANDATORY main() function** with task data and print statements
4. **MANDATORY execution block**: if __name__ == "__main__": main()

**❗❗❗ SCRIPT MUST END WITH THIS EXACT PATTERN:**
```python
def main():
    task_data = {{
        'id': '{task_id}',
        'task_type': '{task_type}',
        'domain': '{domain}',
        'query': '''{query[:200]}...''',
        'ground_truth_plan': '''{ground_truth_plan[:150]}...'''
    }}
    
    print("PlanBench Validation Results")
    print("="*50)
    print(f"Task: {{task_data['task_type']}}")
    print(f"Domain: {{task_data['domain']}}")
    
    validator = PlanValidator()
    results = validator.run_comprehensive_validation(task_data)
    
    print("\\nScores:")
    for k, v in results['scores']['criteria_scores'].items():
        print(f"  {{k}}: {{v:.2f}}")
    
    print(f"\\nTotal: {{results['scores']['weighted_score']:.2f}}/100")
    print(f"Grade: {{results['scores']['grade']}}")

if __name__ == "__main__":
    main()
```

**VALIDATION CHECKS - YOUR OUTPUT MUST CONTAIN:**
- "def main():"
- "if __name__ == \"__main__\":"
- Print statements in main()
- Task data dictionary
- validator.run_comprehensive_validation() call

Generate ONLY executable Python code (no markdown blocks):
"""
        return prompt.strip()
    
    def generate_and_debug_script(self, task: Dict) -> str:
        """生成并调试PlanBench验证脚本"""
        print(f"\n{'='*60}")
        print(f"为规划任务生成验证脚本: {task.get('task_type', 'N/A')}...")
        print("="*60)
        
        # 步骤1: 生成初始脚本
        print("步骤1: 生成初始PlanBench验证脚本...")
        try:
            prompt = self.generate_enhanced_planning_prompt(task)
            print(f"发送prompt到GPT-4o (长度: {len(prompt)} 字符)...")
            
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You are an expert Python code generator specializing in planning task validation scripts. Generate only executable Python code without any markdown formatting."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=5000,
                temperature=0.3
            )
            
            script_content = response.choices[0].message.content.strip()
            script_content = self._clean_markdown_formatting(script_content)
            print("✅ 成功生成规划验证脚本")
            
        except Exception as e:
            print(f"❌ 脚本生成错误: {e}")
            return None
        
        # 步骤2: 系统反馈自调试
        print("步骤2: 通过系统反馈进行自调试...")
        debugged_script = self._debug_with_system_feedback(script_content, task, max_iterations=2)
        
        # 步骤3: 自我反思调试
        print("步骤3: 通过自我反思进行调试...")
        final_script = self._debug_with_self_reflection(debugged_script, task)
        
        return final_script
    
    def _clean_markdown_formatting(self, content: str) -> str:
        """清理markdown格式"""
        if "```python" in content:
            content = content.split("```python")[1]
            if "```" in content:
                content = content.split("```")[0]
        elif "```" in content:
            parts = content.split("```")
            if len(parts) >= 3:
                content = parts[1]
        return content.strip()
    
    def _debug_with_system_feedback(self, script: str, task: Dict, max_iterations: int = 2) -> str:
        """通过系统反馈进行自调试"""
        current_script = script
        
        for iteration in range(1, max_iterations + 1):
            print(f"系统反馈调试迭代 {iteration}/{max_iterations}")
            
            execution_result = self._test_script_execution(current_script)
            
            if execution_result['success']:
                print("✅ 脚本执行成功")
                break
            else:
                print(f"❌ 脚本执行错误: {execution_result['error']}")
                
                debug_prompt = f"""
Fix this PlanBench validation script error:

**ERROR:** {execution_result.get('error', 'Unknown')}

**SCRIPT:** {current_script[:1000]}...

Return only the corrected Python code without markdown formatting.
"""
                
                try:
                    response = self.client.chat.completions.create(
                        model="gpt-4o",
                        messages=[
                            {"role": "system", "content": "Fix the Python code and return only corrected code."},
                            {"role": "user", "content": debug_prompt}
                        ],
                        max_tokens=3000,
                        temperature=0.1
                    )
                    
                    current_script = response.choices[0].message.content.strip()
                    current_script = self._clean_markdown_formatting(current_script)
                    print(f"生成调试迭代 {iteration}")
                    
                except Exception as e:
                    print(f"❌ 调试迭代 {iteration} 失败: {e}")
                    break
        
        return current_script
    
    def _test_script_execution(self, script: str) -> Dict:
        """测试脚本执行"""
        try:
            test_globals = {
                '__builtins__': __builtins__,
                'print': print,
                'os': __import__('os'),
                'json': __import__('json'),
                're': __import__('re'),
                'traceback': __import__('traceback'),
                'typing': __import__('typing')
            }
            
            exec(script, test_globals)
            return {'success': True}
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'traceback': traceback.format_exc()
            }
    
    def _debug_with_self_reflection(self, script: str, task: Dict) -> str:
        """通过自我反思进行调试"""
        print("生成自我反思调试...")
        
        reflection_prompt = f"""
Improve this PlanBench validation script for planning task: {task.get('task_type', 'N/A')}

**CURRENT SCRIPT:** {script[:1000]}...

Enhance for better:
- Planning validation accuracy
- Error handling
- Code efficiency
- Scoring comprehensiveness

Return only improved Python code without markdown formatting.
"""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "Improve the code quality and return only enhanced Python code."},
                    {"role": "user", "content": reflection_prompt}
                ],
                max_tokens=3000,
                temperature=0.1
            )
            
            improved_script = response.choices[0].message.content.strip()
            improved_script = self._clean_markdown_formatting(improved_script)
            print("✅ 完成自我反思改进")
            return improved_script
            
        except Exception as e:
            print(f"❌ 自我反思过程中出错: {e}")
            return script

    def run_validation_pipeline(self) -> Dict[str, str]:
        """运行完整的PlanBench验证脚本生成流程"""
        
        print("开始PlanBench规划任务验证脚本生成流程...")
        print("="*80)
        
        # 分析并选择代表性任务
        selected_tasks = self.analyze_tasks()
        
        generated_scripts = {}
        
        for i, task in enumerate(selected_tasks):
            task_id = f"task_{i+1}_{task.get('task_type', 'unknown').split('_')[-1]}"
            
            # 生成并调试验证脚本
            script = self.generate_and_debug_script(task)
            
            if script:
                generated_scripts[task_id] = {
                    'script': script,
                    'task_info': {
                        'id': task.get('id', 'N/A'),
                        'task_type': task.get('task_type', 'N/A'),
                        'domain': task.get('domain', 'N/A'),
                        'category': task.get('category', 'N/A'),
                        'complexity_level': task.get('complexity_level', 'N/A'),
                        'related_concepts': task.get('related_concepts', []),
                        'has_real_data': task.get('has_real_data', False),
                        'query_preview': task.get('query', 'N/A')[:100] + "..."
                    }
                }
                
                # 保存脚本到文件
                filename = f"planbench_validation_script_{task_id}.py"
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(script)
                print(f"✅ 生成并保存PlanBench验证脚本: {filename}")
        
        return generated_scripts

def main():
    """主函数 - 运行PlanBench验证脚本生成器"""
    print("\n" + "="*70)
    print("PlanBench 规划任务验证脚本生成器")
    print("基于Mind2Web2方法论，使用HuggingFace真实规划数据")
    print("="*70)
    
    # 创建生成器实例
    generator = PlanBenchValidationGenerator(client, planbench_loader)
    
    # 运行完整流程，使用REAL PlanBench任务
    results = generator.run_validation_pipeline()
    
    # 打印总结
    print("\n" + "="*80)
    print("PLANBENCH 生成完成 - 总结")
    print("="*80)
    
    for task_id, data in results.items():
        print(f"\n📋 {task_id.upper()}:")
        print(f"   Real Task ID: {data['task_info']['id']}")
        print(f"   Task Type: {data['task_info']['task_type']}")
        print(f"   Domain: {data['task_info']['domain']}")
        print(f"   Category: {data['task_info']['category']}")
        print(f"   Complexity: {data['task_info']['complexity_level']}")
        print(f"   Related Concepts: {', '.join(data['task_info']['related_concepts'])}")
        print(f"   Has Real Data: {data['task_info']['has_real_data']}")
        print(f"   Query Preview: {data['task_info']['query_preview']}")
        print(f"   Script Length: {len(data['script'])} characters")
        print(f"   File: planbench_validation_script_{task_id}.py")
    
    print(f"\n✅ Successfully generated {len(results)} REAL PlanBench validation scripts")
    print("📁 All scripts saved to current directory")
    print("🎯 Using authentic PlanBench dataset with real planning tasks from HuggingFace")
    print("📊 Enhanced scoring system for planning task evaluation")

if __name__ == "__main__":
    main() 